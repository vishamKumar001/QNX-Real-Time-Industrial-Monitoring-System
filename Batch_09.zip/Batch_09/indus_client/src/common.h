/*
 * Project: Real-Time Notification System with Shared Memory and Timers
 * Brief: Three QNX sensor clients send 64 KB+ IOV messages. The server
 * validates checksums, queues records in shared memory, processes records
 * on periodic timer ticks, and returns timestamped private fault reports.
 * Team members / roll numbers:
 * 1. __________________ / ______________
 * 2. __________________ / ______________
 * 3. __________________ / ______________
 * Date of evaluation: 17 October 2026
 * Platform: QNX Neutrino RTOS; IDE: QNX Momentics; Language: C
 */
#ifndef COMMON_H
#define COMMON_H

#include <stdint.h>
#include <sys/types.h>
#include <pthread.h>
#include <sys/neutrino.h>

#define SERVER_NAME "rt_notification_server"
#define SHM_NAME "/rt_notification_shm"
#define MAGIC_WORD 0xA55A1234u
#define PAYLOAD_SIZE 65536u
#define QUEUE_CAPACITY 16
#define SAMPLES_PER_SENSOR 30u
#define SENSOR_COUNT 3u
#define TOTAL_SAMPLES 90u
#define MAX_FAULT_EVENTS SAMPLES_PER_SENSOR

#define SENSOR_TEMPERATURE 1u
#define SENSOR_CURRENT 2u
#define SENSOR_VIBRATION 3u

#define MESSAGE_TYPE_SENSOR 1u
#define MESSAGE_TYPE_REPORT 3u
#define PRIORITY_NORMAL 1u
#define PRIORITY_FAULT 2u
#define COMPLETION_PULSE_CODE (_PULSE_CODE_MINAVAIL + 2)
#define SERVER_TIMER_PULSE (_PULSE_CODE_MINAVAIL + 3)
#define SLOT_FREE 0u
#define SLOT_READY 1u

typedef struct {
    uint64_t timestamp_ms;
    float temperature_c;
    float current_a;
    float vibration_rms;
    uint32_t sensor_id;
    uint32_t sample_sequence;
    uint32_t fault_flag;
} TelemetryRecord;

typedef struct {
    uint32_t message_type;
    uint32_t client_id;
    uint32_t payload_size;
    uint32_t notification_id;
    uint32_t priority;
    pid_t client_pid;
    int client_chid;          /* Channel receiving asynchronous completion pulses. */
    int client_report_chid;   /* Separate channel receiving the private report. */
    uint32_t sensor_type;
    uint32_t sample_sequence;
    uint32_t payload_checksum;
    TelemetryRecord record;
} RequestMessage;

typedef struct {
    uint32_t magic;
    RequestMessage request;
} WireHeader;

typedef struct {
    uint32_t notification_id;
    int32_t status;
    uint32_t checksum;
} ResponseMessage;

typedef struct {
    uint32_t sensor_type;
    uint32_t sample_sequence;
    float measured_value;
    uint64_t sample_timestamp_ms;
    uint64_t detection_timestamp_ms;
} FaultEvent;

typedef struct {
    uint32_t message_type;
    uint32_t sensor_type;
    uint32_t samples_processed_for_sensor;
    uint32_t sensor_fault_count;
    uint32_t overall_processed_count;
    uint32_t overall_fault_count;
    uint32_t temperature_faults;
    uint32_t current_faults;
    uint32_t vibration_faults;
    uint32_t machine_status;
    uint32_t event_count;
    FaultEvent events[MAX_FAULT_EVENTS];
} SensorFaultReport;

typedef struct { uint32_t status; } SummaryAcknowledgement;

typedef struct {
    uint32_t state;
    uint32_t priority;
    uint32_t notification_id;
    uint32_t sensor_type;
    uint32_t sample_sequence;
    pid_t client_pid;
    int client_chid;
    int client_report_chid;
    uint64_t arrival_order;
    uint32_t checksum;
    TelemetryRecord record;
} QueueSlot;

/* Process-shared synchronization; worker waits until timer_ticks is nonzero. */
typedef struct {
    uint32_t magic;
    pthread_mutex_t mutex;
    pthread_cond_t condition;
    uint32_t queue_count;
    uint32_t timer_ticks;
    uint64_t next_arrival_order;
    uint32_t total_processed;
    uint32_t total_faults;
    QueueSlot slots[QUEUE_CAPACITY];
} SharedMemory;

#endif
