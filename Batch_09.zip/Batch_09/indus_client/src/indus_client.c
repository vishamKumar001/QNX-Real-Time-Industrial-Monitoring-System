/*
 * Project: Real-Time Notification System with Shared Memory and Timers
 * Brief: Three child processes simulate temperature, current and vibration
 * sensors. Each sends 30 messages with a 65,536-byte IOV payload, waits for an
 * asynchronous completion pulse, then prints and acknowledges its private
 * timestamped fault report.
 * Team members / roll numbers:
 * 1.  Athulya Sakthi M / CB.EN.U4EEE23002
 * 2. Visham Kumar V / CB.EN.U4EEE23047
 * 3. Lakshana S / CB.EN.U4EEE23117
 * Date of evaluation: 17 October 2026
 * Platform: QNX Neutrino RTOS; IDE: QNX Momentics; Language: C
 */
#include "common.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/neutrino.h>
#include <sys/dispatch.h>
#include <sys/uio.h>

#define NAME_OPEN_RETRIES 55       /* 55 x 200 ms = about 11 seconds (>10 s). */
#define NAME_OPEN_DELAY_MS 200
#define SAMPLE_INTERVAL_MS 1000

static uint64_t now_ms(void) {
    struct timespec ts;
    if(clock_gettime(CLOCK_REALTIME,&ts)==-1){perror("clock_gettime");return 0;}
    return (uint64_t)ts.tv_sec*1000ULL+(uint64_t)ts.tv_nsec/1000000ULL;
}
static uint32_t checksum(const void *data,size_t n) {
    const unsigned char *p=data;uint32_t h=2166136261u;size_t i;
    for(i=0;i<n;i++){h^=p[i];h*=16777619u;}return h;
}
static const char *sensor_name(uint32_t t) {
    switch(t){case SENSOR_TEMPERATURE:return "TEMPERATURE";case SENSOR_CURRENT:return "CURRENT";case SENSOR_VIBRATION:return "VIBRATION";default:return "UNKNOWN";}
}
static float value_of(uint32_t t,const TelemetryRecord *r) {
    switch(t){case SENSOR_TEMPERATURE:return r->temperature_c;case SENSOR_CURRENT:return r->current_a;case SENSOR_VIBRATION:return r->vibration_rms;default:return 0.0f;}
}

/* Ten deterministic readings repeat three times for exactly 30 samples. */
static void make_reading(uint32_t t,unsigned seq,TelemetryRecord *r) {
    static const float temp[10]={35,40,100,42,38,45,83,41,36,39};
    static const float current[10]={5,7,13,6,8,4,12.5f,9,5.5f,14};
    static const float vibration[10]={1,2,5,1,3,4.8f,2,1,6,3};
    unsigned i=(seq-1u)%10u;memset(r,0,sizeof(*r));
    r->timestamp_ms=now_ms();r->sensor_id=t;r->sample_sequence=seq;
    if(t==SENSOR_TEMPERATURE){r->temperature_c=temp[i];r->fault_flag=r->temperature_c>=80.0f;}
    else if(t==SENSOR_CURRENT){r->current_a=current[i];r->fault_flag=r->current_a>12.0f;}
    else if(t==SENSOR_VIBRATION){r->vibration_rms=vibration[i];r->fault_flag=r->vibration_rms>=4.5f;}
}
static void make_payload(unsigned char *p,uint32_t type,unsigned seq) {
    size_t i;for(i=0;i<PAYLOAD_SIZE;i++)p[i]=(unsigned char)((i+seq+type)&0xffu);
}

/* Connect via name_open() only; give the server more than ten seconds to start. */
static int connect_server(void) {
    int i;struct timespec d={0,NAME_OPEN_DELAY_MS*1000000L};
    for(i=0;i<NAME_OPEN_RETRIES;i++){int coid=name_open(SERVER_NAME,0);if(coid!=-1)return coid;if(i+1<NAME_OPEN_RETRIES)nanosleep(&d,NULL);}
    fprintf(stderr,"[CLIENT] name_open timed out after about 11 seconds: %s\n",strerror(errno));return -1;
}

/* Wait for the asynchronous pulse matching this notification ID. */
static int wait_completion(int chid,uint32_t id) {
    struct _pulse p;int rcvid;
    for(;;){memset(&p,0,sizeof(p));rcvid=MsgReceive(chid,&p,sizeof(p),NULL);
        if(rcvid==-1){if(errno==EINTR)continue;perror("MsgReceive completion");return -1;}
        if(rcvid==0 && p.code==COMPLETION_PULSE_CODE && (uint32_t)p.value.sival_int==id)return 0;
    }
}

/* Exclusive file lock keeps each report block from interleaving with another. */
static int lock_report(void) {
    int fd=open("/tmp/rt_notification_report.lock",O_CREAT|O_RDWR,0666);struct flock l;
    if(fd==-1){perror("open report lock");return -1;}memset(&l,0,sizeof(l));
    l.l_type=F_WRLCK;l.l_whence=SEEK_SET;l.l_start=0;l.l_len=0;
    while(fcntl(fd,F_SETLKW,&l)==-1){if(errno==EINTR)continue;perror("fcntl report lock");close(fd);return -1;}return fd;
}
static void unlock_report(int fd) {
    struct flock l;memset(&l,0,sizeof(l));l.l_type=F_UNLCK;l.l_whence=SEEK_SET;l.l_start=0;l.l_len=0;
    if(fcntl(fd,F_SETLK,&l)==-1)perror("fcntl unlock report");if(close(fd)==-1)perror("close report lock");
}
static void print_timestamp(uint64_t ms) {
    time_t sec=(time_t)(ms/1000ULL);struct tm tmv;char text[32];
    if(localtime_r(&sec,&tmv)==NULL || strftime(text,sizeof(text),"%Y-%m-%d %H:%M:%S",&tmv)==0){printf("%llu ms since epoch",(unsigned long long)ms);return;}
    printf("%s.%03llu",text,(unsigned long long)(ms%1000ULL));
}

/* Receive, validate, print and acknowledge a sensor-specific private report. */
static int receive_report(int chid,uint32_t expected) {
    SensorFaultReport r;SummaryAcknowledgement ack;struct _msg_info info;int rcvid,fd;unsigned i;
    memset(&r,0,sizeof(r));memset(&info,0,sizeof(info));
    printf("[CLIENT-%s] Waiting for private report...\n",sensor_name(expected));fflush(stdout);
    rcvid=MsgReceive(chid,&r,sizeof(r),&info);
    if(rcvid==-1){perror("MsgReceive private report");return -1;}
    if(rcvid==0){fprintf(stderr,"[CLIENT-%s] Unexpected pulse on report channel.\n",sensor_name(expected));return -1;}
    if((size_t)info.msglen!=sizeof(r) || r.message_type!=MESSAGE_TYPE_REPORT || r.sensor_type!=expected || r.event_count>MAX_FAULT_EVENTS || r.sensor_fault_count!=r.event_count){
        fprintf(stderr,"[CLIENT-%s] Invalid private report.\n",sensor_name(expected));MsgError(rcvid,EINVAL);return -1;
    }
    for(i=0;i<r.event_count;i++)if(r.events[i].sensor_type!=expected){fprintf(stderr,"[CLIENT-%s] Foreign event in report.\n",sensor_name(expected));MsgError(rcvid,EINVAL);return -1;}
    fd=lock_report();if(fd==-1){MsgError(rcvid,EIO);return -1;}
    printf("\n====================================================\n %s CLIENT - PRIVATE FAULT REPORT\n====================================================\n",sensor_name(expected));
    printf("Samples processed for sensor: %u\n",r.samples_processed_for_sensor);
    printf("Faults for this sensor      : %u\n",r.sensor_fault_count);
    printf("Overall readings processed  : %u / %u\n",r.overall_processed_count,TOTAL_SAMPLES);
    printf("Overall system faults       : %u\n",r.overall_fault_count);
    printf("Temperature faults          : %u\nCurrent faults              : %u\nVibration faults            : %u\n",r.temperature_faults,r.current_faults,r.vibration_faults);
    printf("Machine status              : %s\n",r.machine_status?"MOTOR_INSPECTION_REQUIRED":"NORMAL");
    printf("\nFAULT EVENTS - %s ONLY\n----------------------------------------------------\n",sensor_name(expected));
    if(r.event_count==0)printf("No faults detected for this sensor.\n");
    for(i=0;i<r.event_count;i++){
        const FaultEvent *e=&r.events[i];printf("%02u. Sample %02u | Value: %.2f\n",i+1,e->sample_sequence,e->measured_value);
        printf("    Sample timestamp   : ");print_timestamp(e->sample_timestamp_ms);printf("\n");
        printf("    Detection timestamp: ");print_timestamp(e->detection_timestamp_ms);printf("\n");
    }
    printf("====================================================\n[CLIENT-%s] Private report printed successfully.\n",sensor_name(expected));
    /* Flush while locked; otherwise buffered output could interleave later. */
    if(fflush(stdout)==EOF){perror("fflush report");unlock_report(fd);MsgError(rcvid,EIO);return -1;}
    unlock_report(fd);
    memset(&ack,0,sizeof(ack));ack.status=EOK;
    if(MsgReply(rcvid,EOK,&ack,sizeof(ack))==-1){perror("MsgReply report");return -1;}
    return 0;
}

/* Execute one sensor process. */
static int run_sensor(uint32_t type) {
    int pulse_chid=-1,report_chid=-1,coid=-1,result=EXIT_FAILURE;unsigned seq;struct timespec delay={SAMPLE_INTERVAL_MS/1000,(SAMPLE_INTERVAL_MS%1000)*1000000L};
    printf("[CLIENT-%s] Starting; %u samples.\n",sensor_name(type),SAMPLES_PER_SENSOR);fflush(stdout);
    pulse_chid=ChannelCreate(0);if(pulse_chid==-1){perror("ChannelCreate pulse");return EXIT_FAILURE;}
    report_chid=ChannelCreate(0);if(report_chid==-1){perror("ChannelCreate report");ChannelDestroy(pulse_chid);return EXIT_FAILURE;}
    coid=connect_server();if(coid==-1)goto cleanup;result=EXIT_SUCCESS;
    for(seq=1;seq<=SAMPLES_PER_SENSOR;seq++){
        TelemetryRecord rec;WireHeader h;ResponseMessage response;unsigned char *payload;struct iovec siov[2],riov[1];uint32_t id;
        payload=malloc(PAYLOAD_SIZE);if(!payload){perror("malloc payload");result=EXIT_FAILURE;goto cleanup;}
        make_reading(type,seq,&rec);make_payload(payload,type,seq);memset(&h,0,sizeof(h));memset(&response,0,sizeof(response));
        id=type*1000u+seq;h.magic=MAGIC_WORD;h.request.message_type=MESSAGE_TYPE_SENSOR;h.request.client_id=type;
        h.request.payload_size=PAYLOAD_SIZE;h.request.notification_id=id;h.request.priority=rec.fault_flag?PRIORITY_FAULT:PRIORITY_NORMAL;
        h.request.client_pid=getpid();h.request.client_chid=pulse_chid;h.request.client_report_chid=report_chid;
        h.request.sensor_type=type;h.request.sample_sequence=seq;h.request.payload_checksum=checksum(payload,PAYLOAD_SIZE);h.request.record=rec;
        /* Two IOV segments: message header followed by the 65,536-byte payload. */
        siov[0].iov_base=&h;siov[0].iov_len=sizeof(h);siov[1].iov_base=payload;siov[1].iov_len=PAYLOAD_SIZE;
        riov[0].iov_base=&response;riov[0].iov_len=sizeof(response);
        if(MsgSendv(coid,siov,2,riov,1)==-1){perror("MsgSendv");free(payload);result=EXIT_FAILURE;goto cleanup;}free(payload);
        if(response.notification_id!=id){fprintf(stderr,"[CLIENT-%s] Reply ID mismatch.\n",sensor_name(type));result=EXIT_FAILURE;goto cleanup;}
        if(response.status!=EOK){fprintf(stderr,"[CLIENT-%s] Request %u rejected: %s (%d)\n",sensor_name(type),id,strerror(response.status),response.status);result=EXIT_FAILURE;goto cleanup;}
        if(response.checksum!=h.request.payload_checksum){fprintf(stderr,"[CLIENT-%s] Checksum reply mismatch.\n",sensor_name(type));result=EXIT_FAILURE;goto cleanup;}
        if(wait_completion(pulse_chid,id)==-1){result=EXIT_FAILURE;goto cleanup;}
        printf("[CLIENT-%s] Sample %02u/%02u SENT value=%.2f ID=%u checksum=OK completion=OK\n",sensor_name(type),seq,SAMPLES_PER_SENSOR,value_of(type,&rec),id);fflush(stdout);
        if(seq<SAMPLES_PER_SENSOR)nanosleep(&delay,NULL);
    }
    printf("[CLIENT-%s] All samples completed.\n",sensor_name(type));fflush(stdout);
    if(receive_report(report_chid,type)==-1)result=EXIT_FAILURE;
cleanup:
    if(coid!=-1 && name_close(coid)==-1)perror("name_close");
    if(pulse_chid!=-1 && ChannelDestroy(pulse_chid)==-1)perror("ChannelDestroy pulse");
    if(report_chid!=-1 && ChannelDestroy(report_chid)==-1)perror("ChannelDestroy report");
    return result;
}

int main(void) {
    const uint32_t types[SENSOR_COUNT]={SENSOR_TEMPERATURE,SENSOR_CURRENT,SENSOR_VIBRATION};
    pid_t children[SENSOR_COUNT];int created=0,i,status,success=1;
    setvbuf(stdout,NULL,_IOLBF,0);
    printf("====================================================\nQNX SENSOR CLIENT TEST\nThree clients; 30 samples per client\n====================================================\n");
    /* Launch all three clients concurrently. */
    for(i=0;i<(int)SENSOR_COUNT;i++){
        pid_t pid=fork();if(pid==-1){perror("fork");success=0;break;}
        if(pid==0){int child_rc=run_sensor(types[i]);fflush(stdout);fflush(stderr);_exit(child_rc);}
        children[created++]=pid;
    }
    for(i=0;i<created;i++){
        if(waitpid(children[i],&status,0)==-1){perror("waitpid");success=0;continue;}
        if(!WIFEXITED(status)||WEXITSTATUS(status)!=EXIT_SUCCESS)success=0;
    }
    printf("\n====================================================\nCLIENT TEST SUMMARY\nExpected readings : %u\nSamples per client: %u\nAll client reports: %s\n====================================================\n",TOTAL_SAMPLES,SAMPLES_PER_SENSOR,success?"RECEIVED":"ONE OR MORE FAILED");
    return success?EXIT_SUCCESS:EXIT_FAILURE;
}
