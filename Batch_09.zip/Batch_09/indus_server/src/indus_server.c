/*
 * Project: Real-Time Notification System with Shared Memory and Timers
 * Brief: QNX server receives 64 KB+ IOV messages, validates checksums, queues
 * records in shared memory, processes them on periodic timer events, and sends
 * private timestamped fault reports with acknowledgement handshakes.
 * Team members / roll numbers:
 * 1.  Athulya Sakthi M / CB.EN.U4EEE23002
 * 2. Visham Kumar V / CB.EN.U4EEE23047
 * 3. Lakshana S / CB.EN.U4EEE23117
 * Date of evaluation: 17 October 2026
 * Platform: QNX Neutrino RTOS; IDE: QNX Momentics; Language: C
 */
#include "common.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/neutrino.h>
#include <sys/dispatch.h>
#include <sys/mman.h>
#include <sys/stat.h>

#define TIMER_INTERVAL_NS 100000000L /* 100 ms */
static name_attach_t *g_attach;
static SharedMemory *g_shared = MAP_FAILED;
static int g_shm_fd = -1, g_timer_coid = -1;
static timer_t g_timer_id;
static int g_timer_created = 0, g_worker_created = 0, g_reports_sent = 0;
static pthread_t g_worker_thread;
static uint32_t g_processed = 0, g_faults = 0;
static uint32_t g_temp_faults = 0, g_current_faults = 0, g_vibration_faults = 0;
static uint32_t g_sensor_samples[SENSOR_COUNT + 1] = {0};
static pid_t g_client_pid[SENSOR_COUNT + 1] = {0};
static int g_client_chid[SENSOR_COUNT + 1] = {-1,-1,-1,-1};
static int g_report_chid[SENSOR_COUNT + 1] = {-1,-1,-1,-1};
static SensorFaultReport g_reports[SENSOR_COUNT + 1];

static uint64_t now_ms(void) {
    struct timespec ts;
    if (clock_gettime(CLOCK_REALTIME, &ts) == -1) { perror("clock_gettime"); return 0; }
    return (uint64_t)ts.tv_sec * 1000ULL + (uint64_t)ts.tv_nsec / 1000000ULL;
}
static uint32_t checksum(const void *data, size_t n) {
    const unsigned char *p = data; uint32_t h = 2166136261u; size_t i;
    for (i=0;i<n;i++) { h ^= p[i]; h *= 16777619u; }
    return h;
}
static const char *sensor_name(uint32_t t) {
    switch(t) { case SENSOR_TEMPERATURE:return "TEMPERATURE"; case SENSOR_CURRENT:return "CURRENT"; case SENSOR_VIBRATION:return "VIBRATION"; default:return "UNKNOWN"; }
}
static int get_value(const TelemetryRecord *r, uint32_t t, float *v) {
    if (!r || !v) return 0;
    switch(t) { case SENSOR_TEMPERATURE:*v=r->temperature_c;return 1; case SENSOR_CURRENT:*v=r->current_a;return 1; case SENSOR_VIBRATION:*v=r->vibration_rms;return 1; default:return 0; }
}
static int is_fault(uint32_t t, float v) {
    switch(t) { case SENSOR_TEMPERATURE:return v>=80.0f; case SENSOR_CURRENT:return v>12.0f; case SENSOR_VIBRATION:return v>=4.5f; default:return 0; }
}

/* Create shared memory and initialize process-shared mutex/condition variable. */
static int setup_shared_memory(void) {
    pthread_mutexattr_t ma; pthread_condattr_t ca; int rc;
    if (shm_unlink(SHM_NAME)==-1 && errno!=ENOENT) { perror("shm_unlink old"); return -1; }
    g_shm_fd=shm_open(SHM_NAME,O_CREAT|O_EXCL|O_RDWR,0666);
    if(g_shm_fd==-1){perror("shm_open");return -1;}
    if(ftruncate(g_shm_fd,(off_t)sizeof(SharedMemory))==-1){perror("ftruncate");return -1;}
    g_shared=mmap(NULL,sizeof(SharedMemory),PROT_READ|PROT_WRITE,MAP_SHARED,g_shm_fd,0);
    if(g_shared==MAP_FAILED){perror("mmap");return -1;}
    memset(g_shared,0,sizeof(*g_shared)); g_shared->magic=MAGIC_WORD; g_shared->next_arrival_order=1;
    rc=pthread_mutexattr_init(&ma); if(rc){fprintf(stderr,"mutexattr_init: %s\n",strerror(rc));return -1;}
    rc=pthread_mutexattr_setpshared(&ma,PTHREAD_PROCESS_SHARED);
    if(rc){fprintf(stderr,"mutexattr_setpshared: %s\n",strerror(rc));pthread_mutexattr_destroy(&ma);return -1;}
    rc=pthread_mutex_init(&g_shared->mutex,&ma); pthread_mutexattr_destroy(&ma);
    if(rc){fprintf(stderr,"mutex_init: %s\n",strerror(rc));return -1;}
    rc=pthread_condattr_init(&ca); if(rc){fprintf(stderr,"condattr_init: %s\n",strerror(rc));return -1;}
    rc=pthread_condattr_setpshared(&ca,PTHREAD_PROCESS_SHARED);
    if(rc){fprintf(stderr,"condattr_setpshared: %s\n",strerror(rc));pthread_condattr_destroy(&ca);return -1;}
    rc=pthread_cond_init(&g_shared->condition,&ca); pthread_condattr_destroy(&ca);
    if(rc){fprintf(stderr,"cond_init: %s\n",strerror(rc));return -1;}
    printf("[SERVER] Shared memory, mutex and condition variable initialized.\n"); return 0;
}

/* Timer sends a pulse to the server's channel; main thread wakes worker. */
static int setup_timer(int chid) {
    struct sigevent ev; struct itimerspec its;
    g_timer_coid=ConnectAttach(0,getpid(),chid,_NTO_SIDE_CHANNEL,0);
    if(g_timer_coid==-1){perror("ConnectAttach timer");return -1;}
    SIGEV_PULSE_INIT(&ev,g_timer_coid,SIGEV_PULSE_PRIO_INHERIT,SERVER_TIMER_PULSE,0);
    if(timer_create(CLOCK_REALTIME,&ev,&g_timer_id)==-1){perror("timer_create");return -1;}
    g_timer_created=1; memset(&its,0,sizeof(its));
    its.it_value.tv_nsec=TIMER_INTERVAL_NS; its.it_interval.tv_nsec=TIMER_INTERVAL_NS;
    if(timer_settime(g_timer_id,0,&its,NULL)==-1){perror("timer_settime");return -1;}
    printf("[SERVER] Periodic timer started (100 ms).\n"); return 0;
}

/* Insert one validated record into the shared-memory queue. */
static int enqueue(const WireHeader *h) {
    int i, free_slot=-1, rc; QueueSlot *s; const RequestMessage *r=&h->request;
    rc=pthread_mutex_lock(&g_shared->mutex); if(rc){fprintf(stderr,"queue lock: %s\n",strerror(rc));return EBUSY;}
    for(i=0;i<QUEUE_CAPACITY;i++) if(g_shared->slots[i].state==SLOT_FREE){free_slot=i;break;}
    if(free_slot<0){pthread_mutex_unlock(&g_shared->mutex);return EBUSY;}
    s=&g_shared->slots[free_slot]; memset(s,0,sizeof(*s));
    s->state=SLOT_READY; s->priority=r->priority; s->notification_id=r->notification_id;
    s->sensor_type=r->sensor_type; s->sample_sequence=r->sample_sequence;
    s->client_pid=r->client_pid; s->client_chid=r->client_chid;
    s->client_report_chid=r->client_report_chid; s->arrival_order=g_shared->next_arrival_order++;
    s->checksum=r->payload_checksum; s->record=r->record; ++g_shared->queue_count;
    /* Wake queue observers; actual processing waits for a periodic timer tick. */
    rc=pthread_cond_broadcast(&g_shared->condition);
    if(rc) fprintf(stderr,"cond_broadcast: %s\n",strerror(rc));
    pthread_mutex_unlock(&g_shared->mutex); return EOK;
}
static void send_completion(pid_t pid,int chid,uint32_t id) {
    int coid=ConnectAttach(0,pid,chid,_NTO_SIDE_CHANNEL,0);
    if(coid==-1){perror("ConnectAttach completion");return;}
    if(MsgSendPulse(coid,SIGEV_PULSE_PRIO_INHERIT,COMPLETION_PULSE_CODE,(int)id)==-1)perror("MsgSendPulse");
    if(ConnectDetach(coid)==-1)perror("ConnectDetach completion");
}

/* Remove one queue item, classify it and store any fault event. */
static int process_one(void) {
    int i,selected=-1,rc,fault; uint32_t best=0; uint64_t oldest=UINT64_MAX;
    QueueSlot item; float value; SensorFaultReport *rep; FaultEvent *e;
    rc=pthread_mutex_lock(&g_shared->mutex); if(rc){fprintf(stderr,"worker lock: %s\n",strerror(rc));return -1;}
    for(i=0;i<QUEUE_CAPACITY;i++) {
        QueueSlot *s=&g_shared->slots[i]; if(s->state!=SLOT_READY)continue;
        if(selected==-1 || s->priority>best || (s->priority==best && s->arrival_order<oldest)) {selected=i;best=s->priority;oldest=s->arrival_order;}
    }
    if(selected==-1){pthread_mutex_unlock(&g_shared->mutex);return 0;}
    item=g_shared->slots[selected]; memset(&g_shared->slots[selected],0,sizeof(QueueSlot));
    if(g_shared->queue_count) --g_shared->queue_count;
    pthread_cond_broadcast(&g_shared->condition); pthread_mutex_unlock(&g_shared->mutex);
    if(!get_value(&item.record,item.sensor_type,&value)){fprintf(stderr,"[SERVER] Invalid queued sensor type.\n");return -1;}
    ++g_processed; ++g_sensor_samples[item.sensor_type]; fault=is_fault(item.sensor_type,value);
    if(fault) {
        ++g_faults;
        if(item.sensor_type==SENSOR_TEMPERATURE)++g_temp_faults;
        else if(item.sensor_type==SENSOR_CURRENT)++g_current_faults;
        else if(item.sensor_type==SENSOR_VIBRATION)++g_vibration_faults;
        rep=&g_reports[item.sensor_type];
        if(rep->event_count<MAX_FAULT_EVENTS) {
            e=&rep->events[rep->event_count++]; e->sensor_type=item.sensor_type;
            e->sample_sequence=item.sample_sequence; e->measured_value=value;
            e->sample_timestamp_ms=item.record.timestamp_ms; e->detection_timestamp_ms=now_ms();
            ++rep->sensor_fault_count;
            printf("[FAULT DETECTED] %-11s sample=%02u value=%.2f\n",sensor_name(item.sensor_type),item.sample_sequence,value);
        }
    }
    printf("[PROCESSED %02u/%02u] %-11s sample=%02u value=%.2f %s\n",g_processed,TOTAL_SAMPLES,sensor_name(item.sensor_type),item.sample_sequence,value,fault?"FAULT":"NORMAL");
    fflush(stdout); send_completion(item.client_pid,item.client_chid,item.notification_id);
    if(pthread_mutex_lock(&g_shared->mutex)==0){g_shared->total_processed=g_processed;g_shared->total_faults=g_faults;pthread_mutex_unlock(&g_shared->mutex);}
    return 1;
}

/* MsgSend blocks until this client's private-report acknowledgement arrives. */
static int send_report(uint32_t type) {
    SensorFaultReport *r=&g_reports[type]; SummaryAcknowledgement ack; int coid;
    if(g_client_pid[type]<=0 || g_report_chid[type]<0){fprintf(stderr,"No report destination for %s\n",sensor_name(type));return -1;}
    r->message_type=MESSAGE_TYPE_REPORT; r->sensor_type=type;
    r->samples_processed_for_sensor=g_sensor_samples[type]; r->overall_processed_count=g_processed;
    r->overall_fault_count=g_faults; r->temperature_faults=g_temp_faults;
    r->current_faults=g_current_faults; r->vibration_faults=g_vibration_faults;
    r->machine_status=(g_faults>0)?1u:0u;
    coid=ConnectAttach(0,g_client_pid[type],g_report_chid[type],_NTO_SIDE_CHANNEL,0);
    if(coid==-1){perror("ConnectAttach report");return -1;}
    printf("[SERVER] Sending %s report: %u faults.\n",sensor_name(type),r->sensor_fault_count);fflush(stdout);
    memset(&ack,0,sizeof(ack));
    if(MsgSend(coid,r,sizeof(*r),&ack,sizeof(ack))==-1){perror("MsgSend report");ConnectDetach(coid);return -1;}
    if(ack.status!=EOK){fprintf(stderr,"[SERVER] Bad report acknowledgement for %s.\n",sensor_name(type));ConnectDetach(coid);return -1;}
    printf("[SERVER] %s client acknowledged its report.\n",sensor_name(type));
    ConnectDetach(coid);return 0;
}
static int send_all_reports(void) {
    if(g_reports_sent || g_processed!=TOTAL_SAMPLES)return 0;
    printf("\n[SERVER] All %u notifications processed.\n",g_processed);
    printf("[SERVER] Fault totals: temperature=%u current=%u vibration=%u total=%u\n",g_temp_faults,g_current_faults,g_vibration_faults,g_faults);
    /* Fixed sequence makes the final report order predictable. */
    if(send_report(SENSOR_TEMPERATURE)==-1)return -1;
    if(send_report(SENSOR_CURRENT)==-1)return -1;
    if(send_report(SENSOR_VIBRATION)==-1)return -1;
    g_reports_sent=1; printf("[SERVER] Report delivery sequence completed.\n");fflush(stdout);return 0;
}

/* Condition-variable worker: it sleeps until the main thread signals a timer tick. */
static void *worker(void *unused) {
    (void)unused;
    for(;;) {
        int rc=pthread_mutex_lock(&g_shared->mutex);
        if(rc){fprintf(stderr,"worker lock: %s\n",strerror(rc));return NULL;}
        while(g_shared->timer_ticks==0) {
            rc=pthread_cond_wait(&g_shared->condition,&g_shared->mutex);
            if(rc){fprintf(stderr,"pthread_cond_wait: %s\n",strerror(rc));pthread_mutex_unlock(&g_shared->mutex);return NULL;}
        }
        --g_shared->timer_ticks; pthread_mutex_unlock(&g_shared->mutex);
        if(process_one()<0)fprintf(stderr,"[SERVER] Queue processing error.\n");
        if(!g_reports_sent && g_processed==TOTAL_SAMPLES && send_all_reports()==-1)
            fprintf(stderr,"[SERVER] Report delivery failed.\n");
    }
    return NULL;
}
static void cleanup(void) {
    if(g_timer_created){timer_delete(g_timer_id);g_timer_created=0;}
    if(g_timer_coid!=-1){ConnectDetach(g_timer_coid);g_timer_coid=-1;}
    if(g_attach){name_detach(g_attach,0);g_attach=NULL;}
    if(g_shared!=MAP_FAILED){pthread_cond_destroy(&g_shared->condition);pthread_mutex_destroy(&g_shared->mutex);munmap(g_shared,sizeof(*g_shared));g_shared=MAP_FAILED;}
    if(g_shm_fd!=-1){close(g_shm_fd);g_shm_fd=-1;}
    if(shm_unlink(SHM_NAME)==-1 && errno!=ENOENT)perror("shm_unlink cleanup");
}

int main(void) {
    WireHeader h; ResponseMessage reply; struct _pulse pulse; struct _msg_info info;
    struct iovec iov[2]; unsigned char payload[PAYLOAD_SIZE]; int rcvid,chid,rc;
    memset(g_reports,0,sizeof(g_reports));
    g_reports[SENSOR_TEMPERATURE].sensor_type=SENSOR_TEMPERATURE;
    g_reports[SENSOR_CURRENT].sensor_type=SENSOR_CURRENT;
    g_reports[SENSOR_VIBRATION].sensor_type=SENSOR_VIBRATION;
    if(setup_shared_memory()==-1){cleanup();return EXIT_FAILURE;}
    g_attach=name_attach(NULL,SERVER_NAME,0);
    if(!g_attach){perror("name_attach");cleanup();return EXIT_FAILURE;}
    chid=g_attach->chid;
    if(setup_timer(chid)==-1){cleanup();return EXIT_FAILURE;}
    rc=pthread_create(&g_worker_thread,NULL,worker,NULL);
    if(rc){fprintf(stderr,"pthread_create: %s\n",strerror(rc));cleanup();return EXIT_FAILURE;}
    g_worker_created=1;
    printf("\n====================================================\nQNX REAL-TIME NOTIFICATION SERVER\nName: %s | Payload: %u bytes | Timer: 100 ms\n====================================================\n",SERVER_NAME,PAYLOAD_SIZE);fflush(stdout);
    for(;;) {
        memset(&h,0,sizeof(h));memset(payload,0,sizeof(payload));memset(&info,0,sizeof(info));
        iov[0].iov_base=&h;iov[0].iov_len=sizeof(h);iov[1].iov_base=payload;iov[1].iov_len=sizeof(payload);
        rcvid=MsgReceivev(chid,iov,2,&info);
        if(rcvid==-1){if(errno==EINTR)continue;perror("MsgReceivev");continue;}
        if(rcvid==0) {
            /* QNX pulses return rcvid == 0; the timer pulse wakes the worker. */
            memcpy(&pulse,&h,sizeof(pulse));
            if(pulse.code==SERVER_TIMER_PULSE && pthread_mutex_lock(&g_shared->mutex)==0) {
                ++g_shared->timer_ticks;pthread_cond_signal(&g_shared->condition);pthread_mutex_unlock(&g_shared->mutex);
            }
            continue;
        }
        memset(&reply,0,sizeof(reply));reply.notification_id=h.request.notification_id;reply.status=EINVAL;
        if((size_t)info.msglen!=sizeof(h)+PAYLOAD_SIZE)reply.status=EMSGSIZE;
        else if(h.magic!=MAGIC_WORD || h.request.message_type!=MESSAGE_TYPE_SENSOR)reply.status=EINVAL;
        else if(h.request.payload_size!=PAYLOAD_SIZE)reply.status=EMSGSIZE;
        else if(h.request.sensor_type<SENSOR_TEMPERATURE || h.request.sensor_type>SENSOR_VIBRATION)reply.status=EINVAL;
        else if(h.request.client_pid<=0 || h.request.client_chid<0 || h.request.client_report_chid<0)reply.status=EINVAL;
        else {
            uint32_t sum=checksum(payload,sizeof(payload));reply.checksum=sum;
            if(sum!=h.request.payload_checksum){reply.status=EBADMSG;fprintf(stderr,"[SERVER] Checksum mismatch ID=%u\n",h.request.notification_id);}
            else {
                uint32_t t=h.request.sensor_type;
                g_client_pid[t]=h.request.client_pid;g_client_chid[t]=h.request.client_chid;g_report_chid[t]=h.request.client_report_chid;
                reply.status=enqueue(&h);
                if(reply.status==EOK){printf("[SERVER] Accepted %-11s ID=%u checksum=OK\n",sensor_name(t),h.request.notification_id);fflush(stdout);}
            }
        }
        /* Immediate reply reports queue acceptance; completion pulse comes later. */
        if(MsgReply(rcvid,EOK,&reply,sizeof(reply))==-1)perror("MsgReply request");
    }
    /* Continuous server loop; cleanup is retained for orderly shutdown extensions. */
    if(g_worker_created)pthread_join(g_worker_thread,NULL);cleanup();return EXIT_SUCCESS;
}
